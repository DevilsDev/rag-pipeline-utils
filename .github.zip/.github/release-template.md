<!-- .github/release-template.md -->

# 🔖 Release v{{VERSION}}

**Published:** `{{DATE}}`  
**Compare changes:** [View diff](https://github.com/DevilsDev/rag-pipeline-utils/compare/{{PREVIOUS_TAG}}...v{{VERSION}})  
**Contributors:** `{{CONTRIBUTORS}}`  
**Commits:** `{{COMMITS}}`

---

## 📦 What's New

- Placeholder for changelog details or highlights.

---

## 📘 Changelog

See full details in [CHANGELOG.md](../../CHANGELOG.md)
